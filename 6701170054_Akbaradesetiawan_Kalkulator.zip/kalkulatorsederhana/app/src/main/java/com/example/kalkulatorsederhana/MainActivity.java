package com.example.kalkulatorsederhana;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText bilpertama, bilkedua, personal;
    Button button1;
    TextView hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bilpertama = (EditText)findViewById(R.id.bil1);
        bilkedua = (EditText)findViewById(R.id.bil2);
        personal = (EditText)findViewById(R.id.personalbil);
        button1 = (Button)findViewById(R.id.b1);
        hasil = (TextView)findViewById(R.id.tvhasil);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (personal.getText().toString().equals("+")){
                    Integer a = Integer.parseInt(bilpertama.getText().toString());
                    Integer b = Integer.parseInt(bilkedua.getText().toString());
                    Integer c = a+b;
                    hasil.setText(Integer.toString(c));
                }else if(personal.getText().toString().equals("-")){
                    Integer a = Integer.parseInt(bilpertama.getText().toString());
                    Integer b = Integer.parseInt(bilkedua.getText().toString());
                    Integer c = a-b;
                    hasil.setText(Integer.toString(c));
                }else if (personal.getText().toString().equals("*")){
                    Integer a = Integer.parseInt(bilpertama.getText().toString());
                    Integer b = Integer.parseInt(bilkedua.getText().toString());
                    Integer c = a*b;
                    hasil.setText(Integer.toString(c));
                }else if (personal.getText().toString().equals("/")){
                    Integer a = Integer.parseInt(bilpertama.getText().toString());
                    Integer b = Integer.parseInt(bilkedua.getText().toString());
                    Integer c = a/b;
                    hasil.setText(Integer.toString(c));
                }else {
                    Toast.makeText(MainActivity.this, "OPERASI ARITMATIKA TIDAK SESUAI", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}